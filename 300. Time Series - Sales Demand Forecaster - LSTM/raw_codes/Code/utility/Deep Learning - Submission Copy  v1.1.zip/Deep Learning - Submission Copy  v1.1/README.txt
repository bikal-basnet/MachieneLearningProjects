## Usage : pip  install -r requirements_setup.txt


## MatPlotLib
## sudo apt-get install python-matplotlib
## sudo apt-get install libhdf5-dev
# sudo apt-get install python-pip

# if python-dev install requested sudo apt-get install python-dev
# For ubuntu 15.04 :: sudo pip install fails
#  sudo apt-get install python-numpy
#                      sudo apt-get install python-scipy

sklearn
scipy
numpy
h5py
keras



