import scipy
import numpy
import sklearn

print('hello')